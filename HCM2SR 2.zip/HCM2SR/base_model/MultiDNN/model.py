# -*- coding: utf-8 -*-
# Time  : 2022/4/12
# Author: slmu
# Email : mushanlei.msl@alibaba-inc.com

from multirec.model.BaseDNN.model import BaseDNN


class MultiDNN(BaseDNN):
    pass
