# -*- coding: utf-8 -*-
# Time  : 2022/4/12
# Author: slmu
# Email : mushanlei.msl@alibaba-inc.com

import os
import torch

from multirec.base.base_dataset import BaseDataset


class MultiDNNTrainDataset(BaseDataset):

    def __init__(self, args):
        super(MultiDNNTrainDataset, self).__init__(args, 'train')
        self.group = args.group

        self.data_file = os.path.join(self.data_dir, self.group, 'train.csv')
        self.dataset_contents = self.load_dataset_contents(self.data_file)
        self.data_size = len(self.dataset_contents)

    def read_data_from_line(self, raw_data):
        data = raw_data.strip().split(',')
        discrete_features = data[self.feature_region[0]:self.feature_region[1] + 1]
        discrete_features = list(map(int, discrete_features))
        label = float(data[-3]) if self.task.lower() == 'ctr' else float(data[-2])
        return discrete_features, label

    def __getitem__(self, index):
        raw_data = self.dataset_contents[index]
        features, label = self.read_data_from_line(raw_data)

        features = torch.tensor(features)
        label = torch.tensor(label)

        return features, label


class MultiDNNEvalDataset(BaseDataset):

    def __init__(self, args, dataset_name, scenario_idx, state):
        super(MultiDNNEvalDataset, self).__init__(args, state)

        self.scenario_idx = scenario_idx

        self.data_file = os.path.join(self.data_dir, dataset_name, dataset_name + '_' + state + '.csv')
        self.dataset_contents = self.load_dataset_contents(self.data_file)
        self.data_size = len(self.dataset_contents)

    def __getitem__(self, index):
        raw_data = self.dataset_contents[index]
        features, label = self.read_data_from_line(raw_data)

        features = torch.tensor(features)
        label = torch.tensor(label)

        return features, label
