# -*- coding: utf-8 -*-
# Time  : 2022/4/12
# Author: slmu
# Email : mushanlei.msl@alibaba-inc.com

from multirec.base.base_trainer import BaseMultiTrainer


class MultiDNNTrainer(BaseMultiTrainer):
    pass
