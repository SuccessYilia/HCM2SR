# -*- coding: utf-8 -*-
# Time  : 2022/5/6
# Author: slmu
# Email : mushanlei.msl@alibaba-inc.com

import torch

from multirec.model.MultiDNN.dataset import MultiDNNTrainDataset, MultiDNNEvalDataset


class SharedBottomTrainDataset(MultiDNNTrainDataset):

    def __init__(self, args):
        super(SharedBottomTrainDataset, self).__init__(args)

    def read_data_from_line(self, raw_data):
        data = raw_data.strip().split(',')
        discrete_features = data[self.feature_region[0]:self.feature_region[1] + 1]
        discrete_features = list(map(int, discrete_features))
        scenario_idx = int(data[-1])
        label = float(data[-3]) if self.task.lower() == 'ctr' else float(data[-2])
        return discrete_features, scenario_idx, label

    def __getitem__(self, index):
        raw_data = self.dataset_contents[index]
        features, scenario_idx, label = self.read_data_from_line(raw_data)

        features = torch.tensor(features)
        scenario_idx = torch.tensor(scenario_idx)
        label = torch.tensor(label)

        return features, scenario_idx, label


class SharedBottomEvalDataset(MultiDNNEvalDataset):

    def __getitem__(self, index):
        raw_data = self.dataset_contents[index]
        features, label = self.read_data_from_line(raw_data)

        features = torch.tensor(features)
        scenario_idx = torch.tensor(self.scenario_idx)
        label = torch.tensor(label)

        return features, scenario_idx, label
