# -*- coding: utf-8 -*-
# Time  : 2022/5/6
# Author: slmu
# Email : mushanlei.msl@alibaba-inc.com

import torch
import torch.nn as nn

from multirec.base.base_model import BaseModel
from multirec.base.layers import DiscreteEmbeddingLayers, MLPLayers, xavier_normal_initialization


class SharedBottom(BaseModel):

    def __init__(self, args, dataset):
        super(SharedBottom, self).__init__(args, dataset)

        # load parameters info
        self.n_scenarios = args.n_scenarios
        self.dropout_ratio = args.dropout_ratio
        self.activation = args.activation
        self.shared_mlp_layer_dim_list = eval(args.shared_mlp_layers)
        self.specific_mlp_layer_dim_list = eval(args.specific_mlp_layers)
        self.input_dim = args.input_dim

        # define network
        self.discrete_feature_embed_layer = DiscreteEmbeddingLayers(self.feature_mapping, self.feature_names)
        self.shared_mlp_layer = MLPLayers(layers=[self.input_dim] + self.shared_mlp_layer_dim_list,
                                          dropout=self.dropout_ratio,
                                          activation=self.activation,
                                          bn=True)

        self.specific_mlp_layer_list = []
        self.specific_output_layer_list = []
        for idx in range(self.n_scenarios):
            self.specific_mlp_layer_list.append(
                MLPLayers(layers=[self.shared_mlp_layer_dim_list[-1]] + self.specific_mlp_layer_dim_list,
                          dropout=self.dropout_ratio,
                          activation=self.activation,
                          bn=True))
            self.specific_output_layer_list.append(
                nn.Linear(self.specific_mlp_layer_dim_list[-1], 1))

        self.specific_mlp_layer_list = nn.ModuleList(self.specific_mlp_layer_list)
        self.specific_output_layer_list = nn.ModuleList(self.specific_output_layer_list)
        self.criterion = nn.BCELoss(reduction='mean')

        self.apply(xavier_normal_initialization)

    def calculate_loss(self, *args):
        discrete_features, scenario_idx, label = args[0], args[1], args[2]
        discrete_embeddings = self.discrete_feature_embed_layer(discrete_features)
        input_embeddings = discrete_embeddings
        shared_embeddings = self.shared_mlp_layer(input_embeddings)
        loss_list = []
        for idx in range(self.n_scenarios):
            data_idx = (scenario_idx == idx).nonzero().squeeze()
            selected_embeddings = shared_embeddings[data_idx]
            selected_embeddings = self.specific_mlp_layer_list[idx](selected_embeddings)
            selected_logits = self.specific_output_layer_list[idx](selected_embeddings)
            selected_logits = torch.sigmoid(selected_logits)
            selected_label = label[data_idx]
            loss = self.criterion(selected_logits, selected_label.unsqueeze(1))
            loss_list.append(loss)
        loss = sum(loss_list)
        return loss

    def evaluate(self, *args):
        discrete_features, scenario_idx = args[0], args[1]
        scenario_idx = scenario_idx[0].item()
        discrete_embeddings = self.discrete_feature_embed_layer(discrete_features)
        input_embeddings = discrete_embeddings
        shared_embeddings = self.shared_mlp_layer(input_embeddings)
        specific_embeddings = self.specific_mlp_layer_list[scenario_idx](shared_embeddings)
        logits = self.specific_output_layer_list[scenario_idx](specific_embeddings)
        scores = torch.sigmoid(logits).squeeze()
        return scores

    def generate_shared_embeddings(self, *args):
        discrete_features = args[0]
        discrete_embeddings = self.discrete_feature_embed_layer(discrete_features)
        input_embeddings = discrete_embeddings
        shared_embeddings = self.shared_mlp_layer(input_embeddings)
        return shared_embeddings

    def generate_specific_embeddings(self, *args):
        discrete_features, scenario_idx = args[0], args[1]
        scenario_idx = scenario_idx[0].item()
        discrete_embeddings = self.discrete_feature_embed_layer(discrete_features)
        input_embeddings = discrete_embeddings
        shared_embeddings = self.shared_mlp_layer(input_embeddings)
        specific_embeddings = self.specific_mlp_layer_list[scenario_idx](shared_embeddings)
        return specific_embeddings
