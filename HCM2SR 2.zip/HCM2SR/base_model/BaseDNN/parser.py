# -*- coding: utf-8 -*-
# Time  : 2022/5/6
# Author: slmu
# Email : mushanlei.msl@alibaba-inc.com

from multirec.base.base_parser import BaseParser


class BaseDNNParser(BaseParser):

    def __init__(self):
        super(BaseDNNParser, self).__init__()

        # Parameters for model
        self.parser.add_argument('--mlp_layers', type=str, default='[256,128,64]')
        self.parser.add_argument('--dropout_ratio', type=float, default=0.0)
        self.parser.add_argument('--activation', type=str, default='leakyrelu')
        self.parser.add_argument('--input_dim', type=int, default=632)
        self.parser.add_argument('--output_dim', type=int, default=1)

    def get_model_params_dict(self):
        self.params_dict['mlp'] = ','.join(list(map(str, eval(self.args.mlp_layers))))
        self.params_dict['dropout'] = str(self.args.dropout_ratio)
        self.params_dict['activation'] = self.args.activation
