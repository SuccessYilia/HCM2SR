# -*- coding: utf-8 -*-
# Time  : 2022/5/6
# Author: slmu
# Email : mushanlei.msl@alibaba-inc.com

import os
import torch

from multirec.base.base_dataset import BaseDataset


class BaseDNNDataset(BaseDataset):
    def __init__(self, args, state):
        super(BaseDNNDataset, self).__init__(args, state)

        self.data_file = os.path.join(self.data_dir, self.dataset, self.dataset + '_' + state + '.csv')
        self.dataset_contents = self.load_dataset_contents(self.data_file)
        self.data_size = len(self.dataset_contents)

    def __getitem__(self, index):
        raw_data = self.dataset_contents[index]
        features, label = self.read_data_from_line(raw_data)

        features = torch.tensor(features)
        label = torch.tensor(label)

        return features, label
