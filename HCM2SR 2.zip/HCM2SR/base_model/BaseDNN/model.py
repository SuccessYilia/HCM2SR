# -*- coding: utf-8 -*-
# Time  : 2022/5/6
# Author: slmu
# Email : mushanlei.msl@alibaba-inc.com

import torch
import torch.nn as nn

from multirec.base.base_model import BaseModel
from multirec.base.layers import DiscreteEmbeddingLayers, MLPLayers, xavier_normal_initialization


class BaseDNN(BaseModel):
    def __init__(self, args, dataset):
        super(BaseDNN, self).__init__(args, dataset)

        # load parameters info
        self.dropout_ratio = args.dropout_ratio
        self.activation = args.activation
        self.mlp_layer_dim_list = eval(args.mlp_layers)
        self.input_dim = args.input_dim
        self.output_dim = args.output_dim

        # define network
        self.discrete_feature_embed_layer = DiscreteEmbeddingLayers(self.feature_mapping, self.feature_names)
        self.mlp_layer = MLPLayers(layers=[self.input_dim] + self.mlp_layer_dim_list,
                                   dropout=self.dropout_ratio,
                                   activation=self.activation,
                                   bn=True)
        self.output_layer = nn.Linear(self.mlp_layer_dim_list[-1], self.output_dim)
        self.criterion = nn.BCELoss(reduction='mean')

        self.apply(xavier_normal_initialization)

    def forward(self, input_tensor):
        output = self.output_layer(self.mlp_layer(input_tensor))
        return output

    def calculate_loss(self, *args):
        discrete_features, label = args[0], args[1]
        discrete_embeddings = self.discrete_feature_embed_layer(discrete_features)
        input_embeddings = discrete_embeddings
        logits = torch.sigmoid(self.forward(input_embeddings))
        loss = self.criterion(logits, label.unsqueeze(1))
        return loss

    def evaluate(self, *args):
        discrete_features = args[0]
        discrete_embeddings = self.discrete_feature_embed_layer(discrete_features)
        input_embeddings = discrete_embeddings
        logits = self.forward(input_embeddings)
        scores = torch.sigmoid(logits).squeeze()
        return scores
