# -*- coding: utf-8 -*-
# Time  : 2022/7/1
# Author: slmu
# Email : mushanlei.msl@alibaba-inc.com

import os
import torch
import random
import pickle
import collections

from multirec.base.base_dataset import BaseDataset
from multirec.model.SharedBottom.dataset import SharedBottomEvalDataset


class OurV9TrainDataset(BaseDataset):

    def __init__(self, args):
        super(OurV9TrainDataset, self).__init__(args, 'train')

        self.n_scenarios = args.n_scenarios
        self.n_negs = args.n_negs
        self.g_cl = args.g_cl
        self.s_cl = args.s_cl
        self.cluster_type = args.cluster_type
        self.group = args.group

        self.data_file = os.path.join(self.data_dir, self.group, 'train.csv')
        if self.task == 'ctcvr':
            self.user2cluster_file = os.path.join(self.data_dir, self.group, 'cluster',
                                                  'user2cluster_' + self.cluster_type + '_ctcvr.pkl')
            self.user_cluster2idx_file = os.path.join(self.data_dir, self.group, 'user_cluster2idx_ctcvr.pkl')
            self.label2idx_file = os.path.join(self.data_dir, self.group, 'label2idx_ctcvr.pkl')
        else:
            self.user2cluster_file = os.path.join(self.data_dir, self.group, 'cluster',
                                                  'user2cluster_' + self.cluster_type + '.pkl')
            self.user_cluster2idx_file = os.path.join(self.data_dir, self.group, 'user_cluster2idx.pkl')
            self.label2idx_file = os.path.join(self.data_dir, self.group, 'label2idx.pkl')

        print('Load training file...')
        self.dataset_contents = self.load_dataset_contents(self.data_file)
        print('Load training file done.')

        # load file
        print('Load file from byte file...')
        if self.g_cl or self.s_cl:
            with open(self.user2cluster_file, 'rb') as fp:
                self.user2cluster = pickle.load(fp)
            with open(self.user_cluster2idx_file, 'rb') as fp:
                self.user_cluster2idx = pickle.load(fp)
        with open(self.label2idx_file, 'rb') as fp:
            self.label2idx = pickle.load(fp)
        print('Load Byte file done.')

        print('Random shuffle for candidates...')
        if self.g_cl or self.s_cl:
            self.user_cluster2indicator = collections.defaultdict(int)
            for key in self.user_cluster2idx.keys():
                random.shuffle(self.user_cluster2idx[key])
            self.label2indicator = {'0': 0, '1': 0}
            random.shuffle(self.label2idx['0'])
            random.shuffle(self.label2idx['1'])
        print('Random shuffle done.\n')

        self.data_size = len(self.dataset_contents)

    def read_data_from_line(self, raw_data):
        data = raw_data.strip().split(',')
        discrete_features = data[self.feature_region[0]:self.feature_region[1] + 1]
        discrete_features = list(map(int, discrete_features))
        scenario_idx = int(data[-1])
        label = float(data[-3]) if self.task.lower() == 'ctr' else float(data[-2])
        user_id, item_id = data[1], data[2]
        return discrete_features, user_id, item_id, scenario_idx, label

    def generate_general_contrastive_instances(self, unit_id, label, unit2cluster, unit_cluster2idx, unit_cluster2indicator):
        unit_cluster = unit2cluster[unit_id]
        origin_unit_cluster = '-' + unit_cluster if label == 0 else '+' + unit_cluster
        reverse_unit_cluster = '+' + unit_cluster if label == 0 else '-' + unit_cluster
        reverse_cluster = '1' if label == 0 else '0'

        pos_unit_cans = unit_cluster2idx[origin_unit_cluster]
        neg_unit_cans = unit_cluster2idx[reverse_unit_cluster]
        pos_unit_index = pos_unit_cans[unit_cluster2indicator[origin_unit_cluster] % len(pos_unit_cans)]
        unit_cluster2indicator[origin_unit_cluster] += 1
        neg_unit_indexes = []
        if len(neg_unit_cans) == 0:
            neg_unit_cans = self.label2idx[reverse_cluster]
            for idx in range(self.n_negs):
                neg_unit_index = neg_unit_cans[self.label2indicator[reverse_cluster] % len(neg_unit_cans)]
                neg_unit_indexes.append(neg_unit_index)
                self.label2indicator[reverse_cluster] += 1
        else:
            for idx in range(self.n_negs):
                neg_unit_index = neg_unit_cans[unit_cluster2indicator[reverse_unit_cluster] % len(neg_unit_cans)]
                neg_unit_indexes.append(neg_unit_index)
                unit_cluster2indicator[reverse_unit_cluster] += 1

        raw_data = self.dataset_contents[pos_unit_index]
        pos_unit_features, _, _, _, _ = self.read_data_from_line(raw_data)
        neg_unit_features_list = []
        for neg_unit_index in neg_unit_indexes:
            raw_data = self.dataset_contents[neg_unit_index]
            neg_unit_features, _, _, _, _ = self.read_data_from_line(raw_data)
            neg_unit_features_list.append(neg_unit_features)
        pos_unit_features = torch.tensor(pos_unit_features)
        neg_unit_features = torch.tensor(neg_unit_features_list)
        return pos_unit_features, neg_unit_features

    def generate_specific_contrastive_instances(self, unit_id, label, unit2cluster, unit_cluster2idx, unit_cluster2indicator, index=None):
        unit_cluster = unit2cluster[unit_id]
        reverse_unit_cluster = '-' + unit_cluster if label == 0 else '+' + unit_cluster
        reverse_cluster = '1' if label == 0 else '0'

        neg_unit_cans = unit_cluster2idx[reverse_unit_cluster]
        neg_unit_indexes = []
        if len(neg_unit_cans) == 0:
            neg_unit_cans = self.label2idx[reverse_cluster]
            while len(neg_unit_indexes) < self.n_negs:
                neg_unit_index = neg_unit_cans[self.label2indicator[reverse_cluster] % len(neg_unit_cans)]
                # if neg_unit_index != index:
                neg_unit_indexes.append(neg_unit_index)
                self.label2indicator[reverse_cluster] += 1
        else:
            while len(neg_unit_indexes) < self.n_negs:
                neg_unit_index = neg_unit_cans[unit_cluster2indicator[reverse_unit_cluster] % len(neg_unit_cans)]
                # if neg_unit_index != index:
                neg_unit_indexes.append(neg_unit_index)
                unit_cluster2indicator[reverse_unit_cluster] += 1

        neg_unit_features_list = []
        for neg_unit_index in neg_unit_indexes:
            raw_data = self.dataset_contents[neg_unit_index]
            neg_unit_features, _, _, _, _ = self.read_data_from_line(raw_data)
            neg_unit_features_list.append(neg_unit_features)
        neg_unit_features = torch.tensor(neg_unit_features_list)
        return neg_unit_features

    def __getitem__(self, index):
        raw_data = self.dataset_contents[index]
        features, user_id, item_id, scenario_idx, raw_label = self.read_data_from_line(raw_data)

        features = torch.tensor(features)
        scenario_idx = torch.tensor(scenario_idx)
        label = torch.tensor(raw_label)
        instances = [features, scenario_idx, label]

        if self.g_cl:
            pos_user_features, neg_user_features = \
                self.generate_general_contrastive_instances(user_id, raw_label, self.user2cluster,
                                                            self.user_cluster2idx, self.user_cluster2indicator)
            instances.append(pos_user_features)
            instances.append(neg_user_features)

        if self.s_cl:
            specific_neg_user_features = \
                self.generate_specific_contrastive_instances(user_id, raw_label, self.user2cluster,
                                                             self.user_cluster2idx, self.user_cluster2indicator, index)
            neg_user_scenario_idx = [(scenario_idx + 1) % self.n_scenarios] * self.n_negs
            neg_user_scenario_idx = torch.tensor(neg_user_scenario_idx)
            instances.append(specific_neg_user_features)
            instances.append(neg_user_scenario_idx)

        return instances


class OurV9EvalDataset(SharedBottomEvalDataset):
    pass
