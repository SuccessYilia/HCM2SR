# -*- coding: utf-8 -*-
# Time  : 2023/12/8
# Author: qingqingyi

import torch
import torch.nn as nn
import torch.nn.functional as fn

from multirec.model.SharedBottom.model import SharedBottom


class OurV9(SharedBottom):

    def __init__(self, args, dataset):
        super(OurV9, self).__init__(args, dataset)
        self.g_cl = args.g_cl
        self.s_cl = args.s_cl
        self.s_cl_weight = args.s_cl_weight
        self.g_cl_weight = args.g_cl_weight
        self.s_cl_dropout = args.s_cl_dropout
        self.cl_temp = args.cl_temp
        self.device = args.device

        self.beta_1 = args.beta_1
        self.beta_t = args.beta_t
        self.t = args.t
        self.betas = torch.linspace(self.beta_1, self.beta_t, self.t)
        self.alphas = 1. - self.betas
        self.alphas_bar = torch.cumprod(self.alphas, dim=0)
        self.sqrt_alphas_bar = torch.sqrt(self.alphas_bar).to(self.device)
        self.sqrt_one_minus_alphas_bar = torch.sqrt_(1 - self.alphas_bar).to(self.device)

        self.sigmoid = nn.Sigmoid()
        self.criterion = nn.BCELoss(reduction='sum')

    def calculate_general_cl_loss(self, raw_main_embeddings, shared_main_embeddings, pos_features, neg_features):
        shared_norm_main_embeddings = fn.normalize(shared_main_embeddings, dim=1)
        raw_pos_embeddings = self.discrete_feature_embed_layer(pos_features)
        shared_pos_embeddings = self.shared_mlp_layer(raw_pos_embeddings)
        shared_norm_pos_embeddings = fn.normalize(shared_pos_embeddings, dim=1)
        batch_size, n_negs = neg_features.shape[0], neg_features.shape[1]
        neg_features = neg_features.view(batch_size * n_negs, -1)
        raw_neg_embeddings = self.discrete_feature_embed_layer(neg_features)
        shared_neg_embeddings = self.shared_mlp_layer(raw_neg_embeddings)
        shared_norm_neg_embeddings = fn.normalize(shared_neg_embeddings, dim=1)
        shared_norm_neg_embeddings = shared_norm_neg_embeddings.view(batch_size, n_negs, -1)

        # add diffusion noise
        step = torch.randint(self.t, size=(batch_size * n_negs, ), device=self.device)   # (batch * n_negs)
        noise = torch.randn_like(shared_neg_embeddings).to(self.device)     # (batch * n_negs, embed)
        sqrt_alphas_bar = self.sqrt_alphas_bar[step].unsqueeze(1)
        sqrt_one_minus_alphas_bar = self.sqrt_one_minus_alphas_bar[step].unsqueeze(1)
        shared_noise_embeddings = sqrt_alphas_bar * shared_neg_embeddings + sqrt_one_minus_alphas_bar * noise
        shared_norm_noise_embeddings = fn.normalize(shared_noise_embeddings, dim=1)
        shared_norm_noise_embeddings = shared_norm_noise_embeddings.view(batch_size, n_negs, -1)
        shared_norm_neg_and_noise_embeddings = torch.cat([shared_norm_neg_embeddings, shared_norm_noise_embeddings], dim=1)

        # calculate contrastive weight
        raw_norm_main_embeddings = fn.normalize(raw_main_embeddings, dim=1)
        raw_norm_pos_embeddings = fn.normalize(raw_pos_embeddings, dim=1)
        raw_norm_neg_embeddings = fn.normalize(raw_neg_embeddings, dim=1)
        raw_norm_neg_embeddings = raw_norm_neg_embeddings.view(batch_size, n_negs, -1)
        pos_weight = torch.mul(raw_norm_main_embeddings, raw_norm_pos_embeddings).sum(dim=1)
        pos_weight = self.sigmoid(-pos_weight).detach()
        neg_weight = torch.bmm(raw_norm_neg_embeddings, raw_norm_main_embeddings.unsqueeze(2)).squeeze(2)
        neg_weight = self.sigmoid(-neg_weight).detach()
        neg_weight = torch.cat([neg_weight, neg_weight], dim=1)

        pos_score = torch.mul(shared_norm_main_embeddings, shared_norm_pos_embeddings).sum(dim=1)
        pos_score = pos_weight * torch.exp(pos_score / self.cl_temp)
        neg_scores = torch.bmm(shared_norm_neg_and_noise_embeddings, shared_norm_main_embeddings.unsqueeze(2)).squeeze(
            2)  # (batch, n_negs)
        neg_scores = (neg_weight * torch.exp(neg_scores / self.cl_temp)).sum(dim=1)
        cl_loss = - torch.log(pos_score / (pos_score + neg_scores)).sum()
        return cl_loss

    def calculate_specific_cl_loss(self, shared_main_embeddings, scenario_idx, neg_features, neg_scenario_idx):
        batch_size, n_negs = neg_features.shape[0], neg_features.shape[1]
        neg_features = neg_features.view(batch_size * n_negs, -1)
        raw_neg_embeddings = self.discrete_feature_embed_layer(neg_features)
        shared_neg_embeddings = self.shared_mlp_layer(raw_neg_embeddings)   # (batch * n_negs, dim)
        neg_scenario_idx = neg_scenario_idx.view(batch_size * n_negs, -1).squeeze()  # (batch * n_negs)

        main_embeddings_list, pos_embeddings_list, neg_embeddings_list = [], [], []
        for idx in range(self.n_scenarios):
            data_idx = (scenario_idx == idx).nonzero().squeeze()
            selected_shared_embeddings = shared_main_embeddings[data_idx]
            selected_main_embeddings = self.specific_mlp_layer_list[idx](selected_shared_embeddings)
            selected_pos_embeddings = self.specific_mlp_layer_list[idx](selected_shared_embeddings)
            main_embeddings_list.append(selected_main_embeddings)
            pos_embeddings_list.append(selected_pos_embeddings)

            neg_data_idx = (neg_scenario_idx == idx).nonzero().squeeze()
            selected_neg_embeddings = shared_neg_embeddings[neg_data_idx]
            selected_neg_embeddings = self.specific_mlp_layer_list[idx](selected_neg_embeddings)
            neg_embeddings_list.append(selected_neg_embeddings)

        main_embeddings = torch.cat(main_embeddings_list, dim=0)
        main_embeddings = fn.normalize(main_embeddings, dim=1)  # (batch, dim)
        pos_embeddings = torch.cat(pos_embeddings_list, dim=0)
        pos_embeddings = fn.normalize(pos_embeddings, dim=1)        # (batch, dim)
        neg_embeddings = torch.cat(neg_embeddings_list, dim=0)
        neg_embeddings = fn.normalize(neg_embeddings, dim=1)
        neg_embeddings = neg_embeddings.view(batch_size, n_negs, -1)    # (batch, n_negs, dim)

        pos_score = torch.mul(main_embeddings, pos_embeddings).sum(dim=1)
        pos_score = torch.exp(pos_score / self.cl_temp)
        neg_scores = torch.bmm(neg_embeddings, main_embeddings.unsqueeze(2)).squeeze(2)  # (batch, n_negs)
        neg_scores = torch.exp(neg_scores / self.cl_temp).sum(dim=1)
        cl_loss = - torch.log(pos_score / (pos_score + neg_scores)).sum()
        return cl_loss

    def calculate_loss(self, *args):
        loss_list = []

        # calculate main loss
        features, scenario_idx, label = args[0], args[1], args[2]
        raw_main_embeddings = self.discrete_feature_embed_layer(features)
        shared_main_embeddings = self.shared_mlp_layer(raw_main_embeddings)
        main_loss_list = []
        for idx in range(self.n_scenarios):
            data_idx = (scenario_idx == idx).nonzero().squeeze()
            selected_embeddings = shared_main_embeddings[data_idx]
            selected_embeddings = self.specific_mlp_layer_list[idx](selected_embeddings)
            selected_logits = self.specific_output_layer_list[idx](selected_embeddings)
            selected_logits = torch.sigmoid(selected_logits)
            selected_label = label[data_idx]
            loss = self.criterion(selected_logits, selected_label.unsqueeze(1))
            main_loss_list.append(loss)
        main_loss = sum(main_loss_list) / features.shape[0]
        loss_list.append(main_loss)

        # calculate general contrastive loss
        if self.g_cl:
            general_pos_features, general_neg_features = args[3], args[4]
            general_cl_loss = self.calculate_general_cl_loss(
                raw_main_embeddings, shared_main_embeddings, general_pos_features, general_neg_features)
            general_cl_loss = self.g_cl_weight * general_cl_loss
            loss_list.append(general_cl_loss)

        # calculate specific contrastive loss
        if self.s_cl == 1:
            specific_neg_features, neg_scenario_idx = args[3 + self.g_cl * 2], args[4 + self.g_cl * 2]
            specific_cl_loss = self.calculate_specific_cl_loss(
                shared_main_embeddings, scenario_idx, specific_neg_features, neg_scenario_idx)
            specific_cl_loss = self.s_cl_weight * specific_cl_loss
            loss_list.append(specific_cl_loss)

        return tuple(loss_list)
