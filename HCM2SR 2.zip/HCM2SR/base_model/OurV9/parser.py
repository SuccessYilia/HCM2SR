# -*- coding: utf-8 -*-
# Time  : 2022/7/1
# Author: slmu
# Email : mushanlei.msl@alibaba-inc.com

from multirec.model.SharedBottom.parser import SharedBottomParser


class OurV9Parser(SharedBottomParser):

    def __init__(self):
        super(OurV9Parser, self).__init__()

        # Parameters for model
        self.parser.add_argument('--g_cl', type=int, default=0)
        self.parser.add_argument('--s_cl', type=int, default=0)
        self.parser.add_argument('--g_cl_weight', type=float, default=0.1)
        self.parser.add_argument('--s_cl_weight', type=float, default=0.1)
        self.parser.add_argument('--s_cl_dropout', type=float, default=0.1)
        self.parser.add_argument('--n_negs', type=int, default=5)
        self.parser.add_argument('--cl_temp', type=float, default=0.07)
        self.parser.add_argument('--cluster_type', type=str, default='dssm10000')
        self.parser.add_argument('--beta_1', type=float, default=1e-4)
        self.parser.add_argument('--beta_t', type=float, default=1e-2)
        self.parser.add_argument('--t', type=int, default=10)

    def get_model_params_dict(self):
        self.params_dict['gcl'] = str(bool(self.args.g_cl))
        self.params_dict['scl'] = str(bool(self.args.s_cl))
        self.params_dict['gclweight'] = str(self.args.g_cl_weight)
        self.params_dict['sclweight'] = str(self.args.s_cl_weight)
        self.params_dict['sdropout'] = str(self.args.s_cl_dropout)
        self.params_dict['nnegs'] = str(self.args.n_negs)
        self.params_dict['temp'] = str(self.args.cl_temp)
        self.params_dict['cluster'] = self.args.cluster_type
