# -*- coding: utf-8 -*-
# Time  : 2022/7/4
# Author: slmu
# Email : mushanlei.msl@alibaba-inc.com

from multirec.base.base_trainer import BaseMultiTrainer


class OurV9Trainer(BaseMultiTrainer):
    pass
