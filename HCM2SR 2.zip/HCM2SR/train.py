import torch
import argparse

from multirec.utils.utils import set_device, set_rng_seed
from multirec.utils.utils import get_logger, get_already_paras, get_saved_file, get_result_file
from multirec.utils.utils import import_parser, import_dataset, import_model, import_trainer


def init_args(model_name, params=None):
    parser = import_parser(model_name)()
    args = parser.parse(params)
    args.model = model_name
    args.device = set_device(args.gpu_id)
    args.params_info = parser.get_params_info()
    args.logger = get_logger(args.logger_dir, args.model, args.params_info)
    set_rng_seed(args.seed)
    args.logger('All Parameters: \n', args, '\n')
    args.logger('Parameters info string:\n %s\n' % args.params_info)
    return args


def check_already_paras(params_info, result_file):
    already_paras = get_already_paras(result_file)
    if params_info.strip() in already_paras:
        print('Already run these parameters')
        return {
            'best_valid_score': 0,
            'best_valid_result': None,
            'test_result': None
        }
    else:
        return None


def train(model_name, params=None):
    # init parser
    args = init_args(model_name, params)
    result_file = get_result_file(args.result_dir, args.model, args.dataset)
    args.saved_file = get_saved_file(args.saved_dir, args.model, args.dataset, args.params_info)

    if not args.ignore_check:
        flag = check_already_paras(args.params_info, result_file)
        if flag is not None:
            return flag

    # init dataloader
    train_dataset = import_dataset(model_name)(args, 'train')
    args.logger(train_dataset)
    train_dataloader = torch.utils.data.DataLoader(train_dataset, batch_size=args.batch_size, shuffle=True,
                                                   pin_memory=True, sampler=None, num_workers=args.num_workers)
    test_dataset = import_dataset(model_name)(args, 'test')
    args.logger(test_dataset)
    test_dataloader = torch.utils.data.DataLoader(test_dataset, batch_size=args.eval_batch_size,
                                                  shuffle=False, sampler=None, num_workers=args.num_workers)
    valid_dataloader = None
    if args.valid:
        valid_dataset = import_dataset(model_name)(args, 'valid')
        args.logger(valid_dataset)
        valid_dataloader = torch.utils.data.DataLoader(valid_dataset, batch_size=args.eval_batch_size,
                                                       shuffle=False, sampler=None, num_workers=args.num_workers)

    # init model
    model = import_model(model_name)(args, train_dataset).to(args.device)
    args.logger(model)

    # init trainer
    trainer = import_trainer(model_name)(args, model)
    if args.pretrained_model is not None:
        trainer.load_checkpoint(args.pretrained_model, strict=bool(args.strict), load_optimizer=bool(args.load_optimizer))

    # train
    if args.valid:
        valid_score, valid_result = trainer.train(train_dataloader, valid_dataloader)
    else:
        valid_score, valid_result = trainer.train(train_dataloader)

    # evaluate
    test_result = trainer.evaluate(test_dataloader, load_best_model=True)
    result_output = trainer.generate_final_output(test_result)
    args.logger(result_output)
    with open(result_file, 'a') as fp:
        fp.write(args.params_info + '\n')
        fp.write(result_output + '\n\n')

    return {
        'best_valid_score': valid_score,
        'best_valid_result': valid_result,
        'test_result': test_result
    }

class AKT(object):
    def __init__(self, data_path=None, epoch=10, batch_size=2000, embedding_dim=5, layers=[128,64,32], keep_prob=[0.9,0.7,0.7], batch_norm=1, lamda=1e-6, lr=1e-3, 
                 optimizer='adam', verbose=1, activation='relu', early_stop=1, model_path='AKT', loss_weight=[1.,1.,1.,1.], num_tasks=4, 
                 constraint_weight=0.3, random_seed=2022):
        # bind params to class
        try:
            vocabulary_df = pd.read_csv('config.csv')
        except:
            print('The file "config.csv" (two columns: feature_name, vocabulary_size_of_the_feature) is needed for get the vocabulary size of all features.')
            exit()
        self.vocabulary_size = dict(zip(vocabulary_df.iloc[:, 0].to_list(), vocabulary_df.iloc[:, 1].to_list()))
        assert data_path is not None, 'The data_path(train/dev/test all is ok) is needed for getting the order of all features.'
        with open(data_path) as fr:
            self.all_features = fr.readline().strip().split(',')[num_tasks:]
        self.epoch = epoch
        self.batch_size = batch_size
        self.embedding_dim = embedding_dim
        self.layers = layers
        self.keep_prob = np.array(keep_prob)
        self.no_dropout = np.array([1 for _ in range(len(keep_prob))])
        self.batch_norm = batch_norm
        self.lamda = lamda
        self.lr = lr
        self.optimizer = optimizer
        self.verbose = verbose
        self.activation = activation
        self.early_stop = early_stop
        self.model_path = model_path
        self.loss_weight = loss_weight
        self.num_tasks = num_tasks
        self.constraint_weight = constraint_weight
        self.random_seed = random_seed
        self.trained = False
        self.loaded = False
        assert len(self.layers) == len(self.keep_prob), 'The length of "layers" and "keep_prob" should be same.'
        assert len(self.loss_weight) == self.num_tasks, 'The length of "loss_weight" should be same with the "num_tasks"'
        

        # init all variables in a tensorflow graph
        self._init_graph_AKT()

    def _init_graph_AKT(self):
        '''
        Init a tensorflow Graph containing: input data, variables, model, loss, optimizer
        '''
        print("Init raw AKT graph")
        self.graph = tf.Graph()
        with self.graph.as_default():
            # Set graph level random seed
            tf.set_random_seed(self.random_seed)
            # Variables init.
            self.weights = self._initialize_weights()
            self.train_labels_placeholder = []
            for task_idx in range(self.num_tasks):
                self.train_labels_placeholder.append(tf.placeholder(tf.float64, shape=[None, 1], name='labels{}'.format(task_idx)))
            self.train_phase = tf.placeholder(tf.bool, name='train_phase')
            self.dropout_keeps_placeholder = []
            for drop_idx in range(len(self.keep_prob)):
                self.dropout_keeps_placeholder.append(tf.placeholder(tf.float32, name='dropout_keep{}'.format(drop_idx)))

            # inputs
            self.inputs_placeholder = []
            for column in self.all_features:
                self.inputs_placeholder.append(tf.placeholder(
                    tf.int64, shape=[None, 1], name=column))

            feature_embedding = []
            for column, feature in zip(self.all_features, self.inputs_placeholder):
                embedded = tf.nn.embedding_lookup(self.weights['feature_embeddings_{}'.format(
                    column)], feature)  # [None, 1, K] * num_features
                feature_embedding.append(embedded)
            feature_embedding = tf.keras.layers.concatenate(feature_embedding, axis=-1)  # [None, 1, K * num_features]
            feature_embedding = tf.squeeze(feature_embedding, axis=1)  # [None, K * num_features]
            # AIT
            # for the first task, the ait = the tower
            self.tasks_outputs = []
            ait = tower = self.tower(feature_embedding, task_idx=0)
            task0_output = tf.keras.layers.Dense(1)(ait)
            self.tasks_outputs.append(tf.sigmoid(task0_output, name="pred0"))

            for task_idx in range(1, self.num_tasks):
                transfer = self.transfer(ait, task_idx=task_idx)
                tower = self.tower(feature_embedding, task_idx=task_idx)
                ait = self.attention(tower, transfer)
                taski_output = tf.keras.layers.Dense(1)(ait)
                self.tasks_outputs.append(tf.sigmoid(taski_output, name="pred{}".format(task_idx)))

            # for save model
            keys = [c + ':0' for c in self.all_features]
            self.inputs = dict(zip(keys, self.inputs_placeholder))
            self.inputs['train_phase:0'] = self.train_phase
            dropout_dict = dict(zip(['dropout_keep{}:0'.format(drop_idx) for drop_idx in range(len(self.keep_prob))], self.dropout_keeps_placeholder))
            self.inputs.update(dropout_dict)
            self.outputs = dict(zip(["pred{}:0".format(task_idx) for task_idx in range(self.num_tasks)], self.tasks_outputs))

            # Compute the loss.
            reg_variables = tf.get_collection(
                tf.GraphKeys.REGULARIZATION_LOSSES)
            if self.lamda > 0:
                reg_loss = tf.add_n(reg_variables)
            else:
                reg_loss = 0.
            self.loss = reg_loss
            for task_idx in range(self.num_tasks):
                self.loss += self.loss_weight[task_idx] * tf.losses.log_loss(self.train_labels_placeholder[task_idx], self.tasks_outputs[task_idx])
            # -------label_constraint--------
            label_constraint = 0.
            for task_idx in range(1, self.num_tasks):
                label_constraint += tf.maximum(self.tasks_outputs[task_idx] - self.tasks_outputs[task_idx - 1], tf.zeros_like(self.tasks_outputs[0]))
            self.loss = self.loss + self.constraint_weight * tf.reduce_mean(label_constraint, axis=0)

            update_ops = tf.get_collection(tf.GraphKeys.UPDATE_OPS)
            with tf.control_dependencies(update_ops):
                # Optimizer.
                if self.optimizer == 'adam':
                    self.optimizer = tf.train.AdamOptimizer(learning_rate=self.lr, beta1=0.9,
                                                            beta2=0.999, epsilon=1e-8).minimize(self.loss)
                elif self.optimizer == 'adagrad':
                    self.optimizer = tf.train.AdagradOptimizer(learning_rate=self.lr,
                                                               initial_accumulator_value=1e-8).minimize(self.loss)
                elif self.optimizer == 'gd':
                    self.optimizer = tf.train.GradientDescentOptimizer(learning_rate=self.lr).minimize(
                        self.loss)
                elif self.optimizer == 'moment':
                    self.optimizer = tf.train.MomentumOptimizer(learning_rate=self.lr,
                                                                momentum=0.95).minimize(self.loss)

            # init
            self.saver = tf.train.Saver(var_list=tf.global_variables())
            init = tf.global_variables_initializer()
            gpu_options = tf.GPUOptions(allow_growth=True)
            self.sess = tf.InteractiveSession(
                config=tf.ConfigProto(
                    gpu_options=gpu_options))
            self.sess.run(init)

            # number of params
            total_parameters = 0
            for variable in tf.trainable_variables():
                shape = variable.get_shape()
                variable_parameters = 1
                for dim in shape:
                    variable_parameters *= dim.value
                total_parameters += variable_parameters
            print("#params: %d" % total_parameters)

    def _initialize_weights(self):
        '''
        Init the parameters weights.
        :return: all weights.
        '''
        all_weights = dict()
        l2_reg = tf.contrib.layers.l2_regularizer(self.lamda)
        # attention
        all_weights['attention_w1'] = tf.get_variable(
            initializer=tf.random_normal(
                shape=[self.layers[-1], self.layers[-1]],
                mean=0.0,
                stddev=0.01),
            regularizer=l2_reg, name='attention_w1')  # k * k
        all_weights['attention_w2'] = tf.get_variable(
            initializer=tf.random_normal(
                shape=[self.layers[-1], self.layers[-1]],
                mean=0.0,
                stddev=0.01),
            regularizer=l2_reg, name='attention_w2')  # k * k
        all_weights['attention_w3'] = tf.get_variable(
            initializer=tf.random_normal(
                shape=[self.layers[-1], self.layers[-1]],
                mean=0.0,
                stddev=0.01),
            regularizer=l2_reg, name='attention_w3')  # k * k
        # MLP
        for column in self.all_features:
            all_weights['feature_embeddings_{}'.format(column)] = tf.get_variable(
                initializer=tf.random_normal(
                    shape=[
                        self.vocabulary_size[column],
                        self.embedding_dim],
                    mean=0.0,
                    stddev=0.01),
                regularizer=l2_reg, name='feature_embeddings_{}'.format(column))  # self.vocabulary_size * K
        return all_weights

    def attention(self, tower, transfer):
        '''
        compute the ait attention
        :param tower: the tower, i.e., the q_{t} in the paper, the shape is [None, K]
        :param transfer: the transferred info, i.e., the p_{t-1} in the paper, the shape is [None, K]
        :return: the ait output, the shape is [None, L, K]
        '''
        # (N,L,K)
        inputs = tf.concat([tower[:, None, :], transfer[:, None, :]], axis=1)
        # (N,L,K)*(K,K)->(N,L,K), L=2, K=32 in this.
        Q = tf.tensordot(inputs, self.weights['attention_w1'], axes=1)
        K = tf.tensordot(inputs, self.weights['attention_w2'], axes=1)
        V = tf.tensordot(inputs, self.weights['attention_w3'], axes=1)
        # (N,L)
        a = tf.reduce_sum(tf.multiply(Q, K), axis=-1) / \
            tf.sqrt(tf.cast(inputs.shape[-1], tf.float32))
        a = tf.nn.softmax(a, axis=1)
        # (N,L,K)
        outputs = tf.multiply(a[:, :, None], V)
        return tf.reduce_sum(outputs, axis=1)  # (N, K)

    def tower(self, feature_embedding, task_idx):
        '''
        compute the MLP tower, i.e., the q_{t} in the paper.
        :param task_idx: The task index
        :param feature_embedding: the embedded input.
        :return: the tower.
        '''
        tower = feature_embedding
        for layer_idx in range(len(self.layers)):
            tower = tf.keras.layers.Dense(self.layers[layer_idx])(tower)
            if self.batch_norm:
                tower = self.batch_norm_layer(tower, self.train_phase, scope_bn='bn_{}_{}'.format(task_idx, layer_idx))
            tower = tf.keras.layers.Activation(activation=self.activation)(tower)
            tower = tf.nn.dropout(tower, self.dropout_keeps_placeholder[layer_idx])
        return tower

    def transfer(self, ait, task_idx):
        '''
        compute the transferred info, i.e., the p_{t-1} in the paper.
        :param task_idx: The task index.
        :param ait: the info of the last task, i.e., the z_{t-1} in the paper.
        :return: the transferred info.
        '''
        transfer = tf.keras.layers.Dense(self.layers[-1])(ait)
        if self.batch_norm:
            transfer = self.batch_norm_layer(transfer, self.train_phase, scope_bn='bn_{}_{}'.format(task_idx, len(self.layers)))
        transfer = tf.keras.layers.Activation(activation=self.activation)(transfer)
        transfer = tf.nn.dropout(transfer, self.dropout_keeps_placeholder[-1])
        return transfer

    def batch_norm_layer(self, x, train_phase, scope_bn):
        '''
        BN layer.
        :param x: the input.
        :param train_phase: is train phase?
        :param scope_bn: scope.
        :return: the output of BN layer.
        '''
        bn_train = batch_norm(x, decay=0.9, center=True, scale=True,
                              is_training=True, reuse=None, trainable=True, scope=scope_bn)
        bn_inference = batch_norm(x, decay=0.9, center=True, scale=True,
                                  is_training=False, reuse=True, trainable=True, scope=scope_bn)
        z = tf.cond(train_phase, lambda: bn_train, lambda: bn_inference)
        return z

    def feed(self, data, inputs=None, train_phase=True):
        '''
        fill the feed dict.
        :param inputs: In tf-serving mode, the inputs need be passed in. Other None.
        :param train_phase: is train_phase?
        :param data: x and y
        :return: the filled feed dict.
        '''
        if inputs is not None:
            # tf-serving
            feed_dict = {inputs[-1]: train_phase}
            # feed x
            for column_name, column_placeholder in zip(
                    self.all_features, inputs[:-len(self.keep_prob) - 1]):
                feed_dict[column_placeholder] = data['ids_{}'.format(column_name)]
            # feed dropout
            for layer_idx in range(len(self.layers)):
                feed_dict[inputs[ layer_idx - len(self.keep_prob) - 1]] = self.keep_prob[layer_idx] if train_phase else self.no_dropout[layer_idx]
        else:
            feed_dict = {self.train_phase: train_phase}
            # feed x
            for column_name, column_placeholder in zip(
                    self.all_features, self.inputs_placeholder):
                feed_dict[column_placeholder] = data['ids_{}'.format(column_name)]
            # feed y
            if inputs is None:
                for task_idx in range(self.num_tasks):
                    feed_dict[self.train_labels_placeholder[task_idx]] = data['Y{}'.format(task_idx)]
            # feed dropout
            for layer_idx in range(len(self.layers)):
                feed_dict[self.dropout_keeps_placeholder[layer_idx]] = self.keep_prob[layer_idx] if train_phase else self.no_dropout[layer_idx]
        return feed_dict

if __name__ == '__main__':
    out_parser = argparse.ArgumentParser()
    out_parser.add_argument('--model', type=str, default='BaseDNN')
    out_args, _ = out_parser.parse_known_args()
    train(out_args.model)
